/**
 * @author Kevin Aloysius, Santa Clara University, COEN 275
 */
public enum UnitType {
	F,C;
}
